from .feature_utils import reduce_memory

__all__ = ('reduce_memory')