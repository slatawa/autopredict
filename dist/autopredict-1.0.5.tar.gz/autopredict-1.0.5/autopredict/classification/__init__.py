from .autoClassify import autoClassify
from ._base import _getClassModelsMetadata,_getScaleModels


__all__ = ('autoClassify','_getClassModelsMetadata','_getScaleModels')