from .autoClassify import autoClassify

__all__ = ('autoClassify')