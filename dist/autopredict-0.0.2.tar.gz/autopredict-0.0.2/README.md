# autopredict
Python Library to Automate building of prediction models - classification and regression and feature selection/ranking.
