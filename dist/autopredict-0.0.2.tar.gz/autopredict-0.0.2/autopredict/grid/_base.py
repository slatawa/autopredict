gridDict =  {'LogisticRegression':{'penalty':['l2']
                               ,'C':[0.001,0.1,1,10]}
             ,'DecisionTreeClassifier': {'max_depth':[4,5,6,7,8,9,10]}}
