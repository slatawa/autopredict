gridDict =  {'LogisticRegression':{'penalty':['l1','l2']
                               ,'C':[0.1,1,10]}
             ,'DecisionTreeClassifier': {'max_depth':[4,5,6,7,8,9,10]}}
