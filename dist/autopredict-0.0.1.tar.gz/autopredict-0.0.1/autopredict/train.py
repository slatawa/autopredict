class train:
    def start_train(self):
        return ''