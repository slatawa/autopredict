# autopredict
Python Library to Automate building of prediction models and feature selection
